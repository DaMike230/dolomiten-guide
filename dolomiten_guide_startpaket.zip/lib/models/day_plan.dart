import 'spot.dart';

class DayPlan {
  final int day;
  final String title;
  final String region;
  final String summary;
  final List<Spot> spots;

  const DayPlan({
    required this.day,
    required this.title,
    required this.region,
    required this.summary,
    required this.spots,
  });
}

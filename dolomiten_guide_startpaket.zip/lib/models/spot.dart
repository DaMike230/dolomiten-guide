class Spot {
  final String name;
  final String area;
  final String description;
  final String visitTime;
  final String difficulty;
  final String mapsUrl;

  const Spot({
    required this.name,
    required this.area,
    required this.description,
    required this.visitTime,
    required this.difficulty,
    required this.mapsUrl,
  });
}

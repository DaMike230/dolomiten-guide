import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/day_plan.dart';

class DayDetailScreen extends StatelessWidget {
  final DayPlan dayPlan;

  const DayDetailScreen({
    super.key,
    required this.dayPlan,
  });

  Future<void> _openMap(String url) async {
    final uri = Uri.parse(url);
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tag ${dayPlan.day}'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Text(
            dayPlan.title,
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: 8),
          Text(dayPlan.summary),
          const SizedBox(height: 16),
          ...dayPlan.spots.map((spot) {
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      spot.name,
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 6),
                    Text(spot.area),
                    const SizedBox(height: 8),
                    Text(spot.description),
                    const SizedBox(height: 8),
                    Text('Dauer: ${spot.visitTime}'),
                    Text('Schwierigkeit: ${spot.difficulty}'),
                    const SizedBox(height: 10),
                    FilledButton.icon(
                      onPressed: () => _openMap(spot.mapsUrl),
                      icon: const Icon(Icons.map),
                      label: const Text('In Google Maps öffnen'),
                    ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

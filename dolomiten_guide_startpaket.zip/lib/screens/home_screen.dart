import 'package:flutter/material.dart';
import '../data/trip_data.dart';
import 'day_detail_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dolomiten Guide'),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: tripDays.length,
        itemBuilder: (context, index) {
          final day = tripDays[index];

          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              title: Text('Tag ${day.day}: ${day.title}'),
              subtitle: Text('${day.region}\n${day.summary}'),
              isThreeLine: true,
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DayDetailScreen(dayPlan: day),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
